﻿using MvcService.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MvcService
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        string Register(User user);

        [OperationContract]
        bool Login(string userName, string password);

        [OperationContract]
        List<User> GetUsers();

        [OperationContract]
        string GetUserType(string userName);

        [OperationContract]
        List<Member> AddMemberToDB(List<Member> members);

        [OperationContract]
        bool AddRelationShipToDB(List<RelationShip> relations);

        [OperationContract]
        List<Edit> EditUser(string applicationId);

        [OperationContract]
        List<Member> DeleteMember(Member member);

        [OperationContract]
        List<Member> SearchApplication(Search searchInput);
        
    }
}
