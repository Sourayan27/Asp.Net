﻿using MvcService.DatabaseContext;
using MvcService.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MvcService
{
    public class Service1 : IService1
    {
        ProjectContext context = new ProjectContext();
        public List<Member> AddMemberToDB(List<Member> members)
        {
            List<Member> memberList = new List<Member>();
            var appId = Guid.NewGuid().ToString();
            var existingAppId = string.Empty;

            //checking and assigning application Id for existing member
            foreach (var member in members)
            {

                if (member.ApplicationId != null && member.ApplicationId != string.Empty)
                {
                    existingAppId = member.ApplicationId;
                    break;
                }
            }

            foreach (var member in members)
            {
                try
                {
                    //For adding new members with new application id
                    if (member.ApplicationId == null && existingAppId == string.Empty)
                    {
                        member.ApplicationId = appId;
                        context.Members.Add(member);
                        context.SaveChanges();
                    }

                    //For adding new members with existing application id
                    else if (existingAppId != string.Empty)

                    {
                        appId = existingAppId;
                        member.ApplicationId = appId;
                        //context.Members.Add(member);
                        //context.SaveChanges();

                        if (member.ApplicationId == null)
                        {
                            member.ApplicationId = existingAppId;
                            context.Members.Add(member);
                            context.SaveChanges();
                        }

                        else
                        {
                            context.Entry(member).State = EntityState.Modified;

                            context.SaveChanges();
                        }


                    }

                }
                catch (Exception ex)
                {

                    return memberList;
                }


            }
            memberList = GetMembers(appId);
            return memberList;
        }

        public List<Member> GetMembers(string appId)
        {
            var list = context.Members.Where(x => x.ApplicationId == appId).ToList();
            return list;
        }

        public bool AddRelationShipToDB(List<RelationShip> relations)
        {

            List<RelationShip> ExistingRelation = new List<RelationShip>();

            foreach (var relation in relations)
            {
                List<RelationShip> relationShips = new List<RelationShip>();
                relationShips = context.RelationShips.Where(item => item.FirstMemberId == relation.FirstMemberId && item.SecondMemberId == relation.SecondMemberId).ToList();
                foreach (var rel in relationShips)
                {

                    ExistingRelation.Add(rel);

                }

            }

            try
            {
                foreach (var relation in relations)
                {


                    if (ExistingRelation.Count == 0)
                    {
                        context.RelationShips.Add(relation);
                        context.SaveChanges();
                    }

                    else
                    {

                        foreach (var Exist in ExistingRelation)
                        {

                            if (Exist.RelationShipId == relation.RelationShipId)
                            {

                                Exist.Relation = relation.Relation;
                                context.Entry(Exist).State = EntityState.Modified;

                                context.SaveChanges();

                                break;
                            }
                            else
                            {
                                var Existing = context.RelationShips.Where(item => item.FirstMemberId == relation.FirstMemberId && item.SecondMemberId == relation.SecondMemberId).ToList();
                                if (Existing.Count == 0)
                                {
                                    context.RelationShips.Add(relation);
                                    context.SaveChanges();
                                    break;
                                }
                                else
                                {
                                    if (Exist.RelationShipId == relation.RelationShipId)
                                    {
                                        Exist.Relation = relation.Relation;
                                        context.Entry(Exist).State = EntityState.Modified;
                                        context.SaveChanges();
                                        break;
                                    }
                                }
                            }
                        }
                    }

                }

            }
            catch (Exception ex)
            {

                return false;
            }
            return true;
        }

        public List<Member> DeleteMember(Member member)
        {
            var ApplicationId = member.ApplicationId;
            var DatatobeDeleted = context.Members.Where(x => x.MemberId == member.MemberId).ToList();
            var DatatobeDeletedinRelationMap = context.RelationShips.Where(x => x.FirstMemberId == member.MemberId).ToList();
            var DatatobeDeletedinRelationMapSecondCol = context.RelationShips.Where(x => x.SecondMemberId == member.MemberId).ToList();
            List<Member> list = new List<Member>();
            try
            {
                foreach (var data in DatatobeDeleted)
                    context.Entry(data).State = EntityState.Deleted;
                foreach (var data in DatatobeDeletedinRelationMap)
                    context.Entry(data).State = EntityState.Deleted;
                foreach (var data in DatatobeDeletedinRelationMapSecondCol)
                    context.Entry(data).State = EntityState.Deleted;
                context.SaveChanges();
                list = GetMembers(ApplicationId);
                return list;

            }

            catch (Exception Ex)
            {
                return list;
            }
        }

        public List<Edit> EditUser(string applicationId)
        {
            List<Edit> editUser = new List<Edit>();

            try
            {
                var CountOfMember = context.Members.Where(x => x.ApplicationId == applicationId).ToList();
                List<RelationShip> ExistingUser = new List<RelationShip>();

                foreach (var Existing in CountOfMember)
                {
                    var id = context.RelationShips.Where(x => x.FirstMemberId == Existing.MemberId).ToList();
                    foreach (var i in id)
                    {
                        ExistingUser.Add(i);
                    }

                }
                if (ExistingUser.Count == 0)
                {
                    foreach (var i in CountOfMember)
                    {
                        Edit editUsers = new Edit();
                        editUsers.FirstPersonDicId = new Dictionary<int, int> { };
                        editUsers.SecondPersonDicId = new Dictionary<int, int> { };
                        editUsers.MemberId = i.MemberId;
                        editUsers.ApplicationId = i.ApplicationId;
                        editUsers.FirstName = i.FirstName;
                        editUsers.MI = i.MI;
                        editUsers.LastName = i.LastName;
                        editUsers.Suffix = i.Suffix;
                        editUsers.DateOfBirth = i.DateOfBirth;
                        editUsers.Gender = i.Gender;
                        editUsers.FirstPersonDicId.Add(0, 0);
                        editUsers.SecondPersonDicId.Add(0, 0);
                        editUsers.Relation = string.Empty;

                        editUser.Add(editUsers);


                    }

                }
                else
                {
                    var q = (from ho in context.Members
                             join rs in context.RelationShips on ho.MemberId equals rs.FirstMemberId
                             where ho.ApplicationId.Equals(applicationId)
                             select new
                             {
                                 ho.MemberId,
                                 ho.ApplicationId,
                                 ho.FirstName,
                                 ho.MI,
                                 ho.LastName,
                                 ho.Suffix,
                                 ho.DateOfBirth,
                                 ho.Gender,
                                 rs.RelationShipId,
                                 rs.FirstMemberId,
                                 rs.SecondMemberId,
                                 rs.Relation
                             }).ToList();
                    foreach (var i in q)
                    {
                        Edit editUsers = new Edit();
                        editUsers.FirstPersonDicId = new Dictionary<int, int> { };
                        editUsers.SecondPersonDicId = new Dictionary<int, int> { };
                        editUsers.MemberId = i.MemberId;
                        editUsers.ApplicationId = i.ApplicationId;
                        editUsers.FirstName = i.FirstName;
                        editUsers.MI = i.MI;
                        editUsers.LastName = i.LastName;
                        editUsers.Suffix = i.Suffix;
                        editUsers.DateOfBirth = i.DateOfBirth;
                        editUsers.Gender = i.Gender;
                        editUsers.FirstPersonDicId.Add(i.RelationShipId, i.FirstMemberId);
                        editUsers.SecondPersonDicId.Add(i.RelationShipId, i.SecondMemberId);
                        editUsers.Relation = i.Relation;

                        editUser.Add(editUsers);


                    }
                }

                return editUser;
            }
            catch (Exception ex)
            {
                return editUser;
            }
        }

        public List<User> GetUsers()
        {
            try
            {
                List<User> UserList = context.Users.ToList();
                return UserList;
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        public string GetUserType(string userName)
        {

            List<User> UserList = context.Users.ToList();
            User user = UserList.Where(x => x.Username == userName).FirstOrDefault();
            string userType = user.UserType;
            return userType;

        }

        public bool Login(string userName, string password)
        {
            try
            {
                if (context.Users.Any(x => x.Username == userName && x.Password == password))

                    return true;
                else
                    return false;
            }

            catch (Exception ex)
            {
                return false;
            }
        }

        public string Register(User user)
        {
            try
            {
                context.Users.Add(user);
                context.SaveChanges();
                return "User added Successfully ! Please Log In to continue ! ";

            }
            catch (Exception ex)
            {
                return "Something went wrong ! Please try again !";
            }

        }

        public List<Member> SearchApplication(Search searchInput)
        {
            List<Member> list = new List<Member>();
            try
            {
                list = context.Members.Where(x => x.ApplicationId == searchInput.ApplicationId || x.DateOfBirth == searchInput.DateOfBirth || x.FirstName == searchInput.FirstName || x.LastName == searchInput.LastName).ToList();
            }
            catch (Exception ex)
            {
                return list;
            }
            return list;
        }
    }
}
