﻿using MvcService.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MvcService.DatabaseContext
{
    public class ProjectContext : DbContext
    {
        public ProjectContext() : base("ProjectContext")
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Member> Members { get; set; }
        public DbSet<RelationShip> RelationShips { get; set; }

    }
}