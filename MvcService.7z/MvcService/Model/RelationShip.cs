﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcService.Model
{
    public class RelationShip
    {
        [Key]
        public int RelationShipId { get; set; }

        public int FirstMemberId { get; set; }

        public int SecondMemberId { get; set; }

        public string Relation { get; set; }
    }
}