﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcService.Model
{
    public class Member
    {
        [Key]
        public int MemberId { get; set; }

        public string ApplicationId { get; set; }

        public string FirstName { get; set; }

        public string MI { get; set; }

        public string LastName { get; set; }

        public string Suffix { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Gender { get; set; }
    }
}